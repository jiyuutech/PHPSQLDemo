<?php
define("DB_HOST", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "z7a18q");
define("DB_DATABASE_NAME", "webdevr12");
?>
